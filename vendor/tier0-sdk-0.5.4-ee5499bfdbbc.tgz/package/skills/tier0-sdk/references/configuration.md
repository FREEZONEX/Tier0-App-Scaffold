---
name: tier0-sdk-configuration
version: 0.2.2
description: "Tier0 SDK configuration for Node.js, browser/Vite, OpenAPI, and MQTT."
---

# Configuration

Read this file before writing code that connects to Tier0 or configures any Tier0 runtime value.

Use it when setting up API hosts, API keys, MQTT hosts, browser builds, client initialization, runtime project context, credential handling, or secret handling. Read it before `references/openapi.md`, [`../../tier0-sdk-mq/SKILL.md`](../../tier0-sdk-mq/SKILL.md), framework references, or domain endpoint references whenever the task involves a live Tier0 connection.

## Contents

- Version and installation
- OpenAPI and current-project configuration
- Browser/Vite and dynamic configuration
- MQTT configuration

## Version and pinned App artifacts

For App/Stream deployments with a reviewed artifact/source pack, retain its commit and SHA-256 pin; the npm version alone may identify an older API surface. Otherwise check and update the SDK to the latest published version before use. The SDK's API surface, endpoints, and types evolve; a stale version leads to wrong signatures and missing endpoints.

```bash
npm view @tier0/sdk version        # latest published version
npm ls @tier0/sdk                  # version currently installed
npm install @tier0/sdk@latest      # update to latest
```

MonoApp/scaffold caveat: do not run `npm install` manually inside the scaffold — its install is managed (running it manually can corrupt `node_modules` on the shared volume). Instead, set `@tier0/sdk` to the latest version in `package.json` and let the managed install / preview restart apply it.

## Trusted App/Stream runtime

For `createClient()` from `@tier0/sdk/cloud`, the SWE App host installs `globalThis[Symbol.for('tier0.sdk.app-runtime.v1')]` before App execution. The SDK detects this trusted provider automatically. Business App code must not call a manual installer or supply broker URLs, raw subjects, JWTs, nkey seeds, API keys, or identity headers. The internal provider returns a `Response` for each authorized request. Standalone Node services use the existing server HTTP/App context.

Read [`../tier0-sdk-streams/SKILL.md`](../tier0-sdk-streams/SKILL.md) for request idempotency, disposable subscriptions, asynchronous errors and teardown. Messages have no offline buffer or replay; disconnected publish fails. SDK renewals generate fresh in-memory keys and restore subscriptions only. This runtime does not replace UNS data, file or notification configuration.

## API Key Compatibility Diagnostics

Do not treat every authentication failure as a bad key. First distinguish SDK compatibility from credential, host, permission, and broker failures.

Run the bundled local diagnostic from the application root when any of these symptoms occurs:

- MQTT reports `Not authorized`, CONNACK code 5, or repeatedly reconnects after the platform injects a new API key.
- OpenAPI succeeds with the same key but MQTT fails.
- The key type changed from a service key to an App, personal, agent, or another workspace-encoded key.

```bash
node node_modules/@tier0/sdk/skills/tier0-sdk/scripts/check-api-key-compat.mjs --json
```

If the Skill is installed outside `node_modules`, run the same script from that Skill directory. It reads only the installed package version and `TIER0_API_KEY`; it reports the key type and format but never prints the key or secret.

Compatibility rules:

| Path | Interpretation |
|---|---|
| OpenAPI/HTTP | The SDK sends the API key as an opaque credential. A 401 alone does not prove that the SDK is too old. Check the injected key, host, key status, and permissions. |
| MQTT with `sk-svc-ws...` | Older SDKs already understand the service-key workspace encoding, although upgrading is still preferred. |
| MQTT with `sk-<type>-ws...`, where type is not `svc` | Requires `@tier0/sdk >= 0.5.2` so the SDK derives the correct workspace MQTT username/client ID. Older versions fall back to the Enterprise identity and can be rejected even when OpenAPI works. |

Agent action rules:

1. Inspect the actually installed version (`npm ls @tier0/sdk` or the diagnostic output), not only the dependency range in `package.json`.
2. If a workspace-encoded non-service key is present and the installed SDK is below `0.5.2`, explain the incompatibility and upgrade to `@tier0/sdk@latest`. In a managed MonoApp, update `package.json` and let the platform reinstall/restart it; do not run `npm install` manually inside the scaffold.
3. After the upgrade, restart the application/preview and rerun the diagnostic before retrying MQTT.
4. If the installed SDK is already compatible, do not keep recommending upgrades. Check, in order: whether `TIER0_API_KEY` is injected into the failing runtime, whether the key was revoked/expired or lacks permission, whether the broker URL and `ws`/`wss` transport are correct, and whether the target backend has deployed support for that key type.
5. Do not work around this failure by hard-coding `username`, `clientId`, Workspace ID, or another API key unless the deployment explicitly requires custom MQTT credentials.
6. Never print, log, paste, or return the complete API key. Error reports may include only whether a key is present, its non-secret type, and whether it uses workspace encoding.

## OpenAPI

The OpenAPI client needs:

| Value | Node.js environment | Explicit config |
|---|---|---|
| API base URL | `TIER0_API_HOST` | `configureClient({ apiHost })` |
| API key | `TIER0_API_KEY` | `configureClient({ apiKey })` |

Prefer complete URLs with scheme. The platform or deployment should inject these values; do not hard-code environment-specific hosts in reusable code or skills:

```bash
TIER0_API_HOST=https://<your-tier0-api-host>
TIER0_API_KEY=<your-api-key>
```

### API Key identity is not App user identity

An App API Key is a server-side business credential shared by the application. It does not identify the human currently visiting or operating the App. `systemApi.openapiv1authwhoami()` reports credential context only where that key type supports it; an App API Key cannot be used to query the current end user.

In an App, obtain the signed-in person from the App's own authentication/session layer. Use that identity for authorization, personalization, and audit attribution. When a Tier0 API requires a `userId`, resolve the signed-in person or user-selected person through the appropriate Tier0 member list and keep the resolved ID internal. Never substitute `whoami` or expose an ID input field.

## Current Project

Tier0 application runtimes inject `TIER0_PROJECT_ID`. Read it through the SDK instead of hard-coding a project name or ID:

```typescript
import { getCurrentProjectId } from '@tier0/sdk';

const projectId = getCurrentProjectId();
```

The value is always exposed as a string: Cloud uses a UUID, while Enterprise uses its local numeric ID serialized as a string. An app imported into Enterprise receives the target Enterprise project ID, not the source Cloud project ID.

Call `getCurrentProjectId()` from server/runtime code. Browser bundles cannot read Node.js `process.env` automatically.

## Current App

Tier0 application runtimes inject `APP_ID` with the **agent-platform App UUID**. Read it through the SDK, which validates the format:

```typescript
import { getCurrentAppId } from '@tier0/sdk';

const appId = getCurrentAppId();
```

Call `getCurrentAppId()` from server/runtime code, like `getCurrentProjectId()`: a browser bundle cannot read Node.js `process.env`, so it throws there regardless of what the platform injected.

⚠️ **`APP_ID` is not always the App UUID.** The MonoApp scaffold defaults it to the literal `monoapp`, and a scaffold deployment normally sets it to the *session id* (the same value as `DB_SCHEMA`, e.g. `session-xyz789`). Those values are silently useless as an app identity — APIs that take an appId accept them and then fail to resolve anything. `getCurrentAppId()` throws instead of returning such a value, so read it through the SDK rather than `process.env.APP_ID`, and treat a throw as a platform-side injection problem, not something to work around with a hard-coded UUID.

If `apiHost` has no scheme, the SDK normalizes it as `http://<host>`. For cloud deployments, pass `https://...` explicitly.

```typescript
import { configureClient } from '@tier0/sdk/openapi';

configureClient({
  apiHost: process.env.TIER0_API_HOST,
  apiKey: process.env.TIER0_API_KEY,
});
```

## Browser and Vite

App/Stream clients use the trusted App runtime described above. For other clients, the SDK does not automatically read `VITE_*` variables at runtime. In Vite/browser code, pass values explicitly from `import.meta.env`.

```typescript
import { configureClient } from '@tier0/sdk/openapi';

configureClient({
  apiHost: import.meta.env.VITE_TIER0_API_HOST,
  apiKey: import.meta.env.VITE_TIER0_API_KEY,
});
```

Do not expose long-lived production API keys in browser apps unless the deployment is explicitly designed for that trust model. Prefer short-lived or scoped keys when available.

## Dynamic Configuration

Use getters when the host or key can rotate:

```typescript
configureClient({
  getApiHost: () => process.env.TIER0_API_HOST,
  getApiKey: () => getKeyFromSecureStore(),
});
```

## MQTT

Cloud and Enterprise workspace-encoded keys use `sk-<type>-ws<base36 workspace ID>_<secret>`. The SDK derives `<workspace ID>&open` and a workspace-prefixed client ID for all key types, including `svc`, `per`, and `agent`, and passes the original key as the password. Legacy keys without an encoded workspace retain the `enterprise&open` fallback; explicit username/clientId still take priority.

The MQ client needs:

| Value | Node.js environment | Explicit config |
|---|---|---|
| MQTT WebSocket host | `TIER0_MQTT_HOST` | `new Tier0MQClient({ host })` |
| MQTT WebSocket port | `TIER0_MQTT_PORT` | `new Tier0MQClient({ port })` |
| API key as MQTT password | `TIER0_API_KEY` | `new Tier0MQClient({ password })` |

Host normalization:

- If `host` starts with `ws://` or `wss://`, the SDK uses it directly and appends `/mqtt` if missing.
- If `host` has no WebSocket scheme, port `8084` or an HTTPS browser context selects `wss`; other ports use `ws`. Explicit `secure: true/false` overrides this inference.
- For TLS/cloud brokers, prefer a full injected `wss://host:port/mqtt` URL. Do not hard-code a broker host; use `TIER0_MQTT_HOST` / `TIER0_MQTT_PORT` or runtime config supplied by the platform.

```typescript
import { Tier0MQClient } from '@tier0/sdk/mq';

const client = new Tier0MQClient({
  host: process.env.TIER0_MQTT_HOST,
  port: process.env.TIER0_MQTT_PORT ? Number(process.env.TIER0_MQTT_PORT) : undefined,
  password: process.env.TIER0_API_KEY,
});
```

The MQ username and client ID are generated from the API key workspace segment when possible. Override `username` and `clientId` only when the broker requires custom values.

Use OpenAPI `unsApi.openapiv1unswrite()` for UNS current-value writes. The MQ client publishes raw broker messages and does not guarantee that OpenAPI `read`/`browse` latest values will update.
